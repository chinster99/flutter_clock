/*
*  for any global consts
*  created by achintya kattemalavadi
*  january 2019
*/

final double orbitsdx = -80.0;
